# Kotlin 학습 커리큘럼 (Java/Spring 개발자용, 8주)

> **대상**: Java + Spring Boot 실무 경험자
> **목표**: Kotlin + Spring Boot로 신규 프로젝트(Saveface/Tactful) 백엔드를 설계·구현할 수 있는 수준
> **총 기간**: 약 8주 (평일 1~1.5시간 기준, 조절 가능)
> **방식**: 매주 [개념 → 변환 실습 → 저널 → 주간 회고] 사이클. BOMS 실제 코드를 Kotlin으로 변환해보는 것이 핵심 훈련이다.

## 사용법
1. `weekXX.md`를 한 주에 하나씩 진행한다.
2. 각 파일의 **실습 체크리스트**, **변환 실습 기록**, **저널 답변**, **주간 회고** 칸을 반드시 직접 채운다.
3. IntelliJ의 Java→Kotlin 자동 변환기는 "정답 생성기"가 아니라 "diff 학습 도구"로 쓴다. 변환 결과에서 어색한 부분을 찾아 관용적(idiomatic) Kotlin으로 다시 고치는 과정이 진짜 학습이다.
4. 이 디렉토리를 git으로 관리하고, 실습 코드 저장소 링크를 회고에 남긴다.

## 전체 로드맵

| 단계 | 주차 | 핵심 주제 | 완료 기준 |
|------|------|-----------|-----------|
| 입문 | week01 | 문법, null safety, 클래스 | Kotlin Koans 완주 |
| 초급 | week02–03 | 함수형 스타일, 컬렉션, Java 상호운용 | Java 코드를 관용적 Kotlin으로 변환 가능 |
| 중급 | week04–06 | Spring Boot + Kotlin, 코루틴 기초, 테스트 | Kotlin으로 CRUD API + 테스트 작성 |
| 고급 | week07–08 | 코루틴 심화, DSL, 성능/내부 동작 | 실무 프로젝트(Saveface/Tactful)에 자신 있게 적용 |

## 관련 자료

### 필수
| 자료 | 용도 | 링크 |
|------|------|------|
| Kotlin Koans | week01 필수 실습 | https://play.kotlinlang.org/koans |
| Kotlin 공식 문서 | 전 주차 레퍼런스 | https://kotlinlang.org/docs/home.html |
| Spring 공식 Kotlin 가이드 | week04–05 필독 | https://docs.spring.io/spring-framework/reference/languages/kotlin.html |
| Kotlin Coroutines 공식 가이드 | week05, week07 | https://kotlinlang.org/docs/coroutines-guide.html |
| MockK 공식 문서 | week06 | https://mockk.io |

### 강력 추천
- **『Kotlin in Action』 (2판)** — JetBrains 개발자가 쓴 사실상의 표준서. 주차별 해당 챕터 병행
- **"Java to Kotlin: A Refactoring Guidebook"** (O'Reilly) — Java 개발자의 사고 전환에 특화
- **Spring 공식 튜토리얼 "Building web applications with Spring Boot and Kotlin"**: https://spring.io/guides/tutorials/spring-boot-kotlin
- **Kotlin 공식 "Idioms" 페이지** — 변환 실습 후 답안지처럼 대조: https://kotlinlang.org/docs/idioms.html

### 심화 (커리큘럼 이후)
- 『Kotlin Coroutines: Deep Dive』 (Marcin Moskała)
- Arrow (함수형 라이브러리), Kotlin Multiplatform
- Exposed / Spring Data JDBC + Kotlin (JPA 대안 탐색)

## 학습 원칙
- 튜토리얼만 돌지 않는다. 매주 BOMS 또는 신규 프로젝트의 **실제 코드**에 적용한다.
- `!!`를 쓸 때마다 이유를 주석으로 남긴다. 이유를 못 쓰면 설계가 잘못된 것이다.
- Java와의 차이를 만날 때마다 "왜 Kotlin은 이렇게 설계했나"를 저널에 적는다. 문법 암기보다 설계 철학 이해가 오래간다.
