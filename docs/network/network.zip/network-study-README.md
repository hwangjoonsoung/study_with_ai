# 네트워크 기초 커리큘럼 (개발자용, 10일)

> **대상**: 백엔드 개발자 — 프로토콜을 "이론"이 아니라 "관측 가능한 현상"으로 배운다
> **환경**: Mac mini 홈서버 + Docker + nginx 샌드박스(nginx 커리큘럼 산출물) + BOMS
> **선행**: nginx 커리큘럼 완주 권장 — 이 과정은 nginx 샌드박스를 실험 대상으로 사용한다
> **주 도구**: tcpdump, Wireshark, ss, dig, nc, curl, mtr, tc(netem), mitmproxy

## 사용법
1. `dayXX.md`를 하루(약 2시간)에 하나씩 진행한다.
2. 각 파일의 **브레이크 실험 기록**, **저널 답변**, **숙제** 칸을 반드시 직접 채운다. 숙제는 다음 날 저널 앞부분에서 스스로 채점한다.
3. 모든 개념은 반드시 **패킷/소켓으로 눈으로 확인**한 뒤에 넘어간다. 그림으로 외운 지식은 장애 상황에서 쓸 수 없다.
4. macOS에는 `ss`, `tc`가 없다 — 실험은 Linux 컨테이너 안에서 한다:
   ```bash
   docker run -it --rm --cap-add=NET_ADMIN nicolaka/netshoot
   ```
   netshoot 이미지에 이 커리큘럼의 도구가 전부 들어있다.

## 전체 로드맵

| Phase | 기간 | 주제 | 도달점 |
|-------|------|------|--------|
| 1. 전송 계층 | Day 1–2 | TCP 생애주기, 소켓 상태 | 패킷과 소켓 상태를 읽을 수 있다 |
| 2. 이름과 주소 | Day 3–5 | DNS, NAT/iptables, 라우팅 | "내 요청이 어디로 가는지" 추적할 수 있다 |
| 3. 응용 계층 | Day 6–8 | TLS, HTTP 시맨틱, 커넥션 풀 | 애플리케이션 증상을 네트워크 계층으로 번역할 수 있다 |
| 4. 실전 | Day 9–10 | 카오스 실험, 전체 경로 종합 추적 | 장애를 계층별로 분해해 진단할 수 있다 |

## 관련 자료

### 필수
| 자료 | 용도 | 링크 |
|------|------|------|
| 『그림으로 배우는 HTTP & Network Basic』 또는 『Computer Networking: A Top-Down Approach』 | 개념 병행 독서 | 서점/도서관 |
| High Performance Browser Networking (무료 웹판) | Day 6–8 필독 | https://hpbn.co |
| Julia Evans의 네트워킹 zine/블로그 | 직관 보강 | https://jvns.ca |
| Wireshark 공식 문서 | 필터 문법 레퍼런스 | https://www.wireshark.org/docs/ |

### 강력 추천
- **nicolaka/netshoot** — 네트워크 디버깅 도구 올인원 컨테이너: https://github.com/nicolaka/netshoot
- **RFC 9293 (TCP)**, **RFC 1918 (사설 IP)** — 전부 읽지 말고 해당 Day에 관련 섹션만
- Cloudflare Learning Center — DNS/TLS 개념 글이 잘 정리됨

## 학습 원칙
- 명령어 결과를 복사해 붙이지 말고, **각 줄이 무슨 뜻인지 해설을 달아야** 기록으로 인정한다.
- "안 되는 상황"을 스스로 만들고 로그/패킷만으로 복구하는 것이 이 과정의 절반이다.
- 매일 마지막 질문은 항상 같다: "오늘 배운 것이 과거 실제 장애(MySQL 커넥션 고갈, 502 등)와 어떻게 연결되는가?"
